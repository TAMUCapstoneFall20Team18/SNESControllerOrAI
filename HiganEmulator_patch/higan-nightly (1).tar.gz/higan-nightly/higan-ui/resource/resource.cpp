#include "resource.hpp"

namespace Resource {
}
