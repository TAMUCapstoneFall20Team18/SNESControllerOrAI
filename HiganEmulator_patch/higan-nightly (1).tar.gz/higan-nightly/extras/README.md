Extra files included in official release builds.
