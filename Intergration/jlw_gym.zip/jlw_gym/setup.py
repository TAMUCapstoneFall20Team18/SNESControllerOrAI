from setuptools import setup

setup(name='jlw_gym', version='0.0.1',
      install_requires=['gym']
)
