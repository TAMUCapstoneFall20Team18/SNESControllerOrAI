from gym.envs.registration import register

register(
 id='jlw-snes-v0',
 entry_point='jlw_gym.envs:JLW_SNES_Env',
)
